f <- function (x) {
    return (x)
}

#' Test function 'g'
#'
#' @export
g <- function (p = 1L) {
    checkmate::assert_int (p)
    message ("fn")
}

#' Test function 'fn'
#'
#' @param x A parameter
#' @return Something
#' @export
fn <- function (x) {
    if (is.integer (x)) {
        return (x + 1L)
    } else {
        return ("Nothing")
    }
}
